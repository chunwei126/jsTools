$(function() {
  console.log('Hello Bootstrap5');
});