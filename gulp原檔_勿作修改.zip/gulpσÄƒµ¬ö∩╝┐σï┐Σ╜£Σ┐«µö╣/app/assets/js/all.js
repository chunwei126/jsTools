console.log('Hello!');

$(document).ready(() => {
  console.log('HesSchool Hello!');
});